package br.com.ana.lima.detran;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pw3DetranApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pw3DetranApplication.class, args);
	}

}
