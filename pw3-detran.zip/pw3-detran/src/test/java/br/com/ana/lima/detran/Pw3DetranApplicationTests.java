package br.com.ana.lima.detran;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pw3DetranApplicationTests {

	@Test
	void contextLoads() {
	}

}
